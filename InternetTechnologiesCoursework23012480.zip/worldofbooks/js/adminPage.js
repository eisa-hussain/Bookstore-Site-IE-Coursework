$(document).ready(function(){



    bookUrl = 'https://www.googleapis.com/books/v1/volumes?q=isbn:'
    var placeHolder = 'https://via.placeholder.com/150'    

    $("#findBookToAdd").click(function(){
        
        $("#displayBook").empty();
        isbnToSearch = $("#enterISBN").val();
        
        
        if(isbnToSearch === "" || isbnToSearch === undefined){
            alert("no input");
        }
        else{
            $.ajax({
                url: bookUrl + isbnToSearch,
                dataType: "json",
                success: function(response) {
                  
                  
                  if (response.totalItems === 0) {
                    alert("No book found")
                  }
                  else {
                    displayResults(response);
                    //console.log(response);
                  }
                },
                error: function () {
                  alert("Something went wrong.. <br>"+"Try again!");
                }
            });
            
        }
            
    })          



    function displayResults(results){

        
        for (var i = 0; i < 1 ;i++){
            

            item = results.items[i];
            title = item.volumeInfo.title;
            author = item.volumeInfo.authors;
            publisher = item.volumeInfo.publisher;
            bookLink = item.volumeInfo.previewLink;
            bookImg = (item.volumeInfo.imageLinks) ? item.volumeInfo.imageLinks.thumbnail : placeHolder ; 
            console.log(isbnToSearch);
            

            var htmlContent = `
            
            <div class="card mb-2" style="width: 18rem;">
                <img class="card-img-top" src="${bookImg}" >
                <div class="card-body">
                    <h5 class="card-title">${title}</h5>
                    <p class="card-text">${author}</p>
                    <ul class="list-group list-group-flush">
                        <form class ="form-inline" id="addBookForm" action="addBookToDatabase.php" method="post">
                        <div class="col-sm-7 mb-1">
                            <label for="isbn" class="form-label">ISBN</label>
                            <input type="text" class="form-control" id="isbn" name="isbn" placeholder="" value="${isbnToSearch}" readonly>
                            
                        </div>
                        
                        <div class="col-sm-6">
                            <label for="price" class="form-label">Price (GBP)</label>
                            <input type="number" class="form-control" id="price" name="price" placeholder="" value="" min="0.01" step="0.01" required>
                            
                        </div>
            
                        <div class="col-sm-6">
                            <label for="quantity" class="form-label">Quantity</label>
                            <input type="number" class="form-control" id="quantity" name="quantity" placeholder="" value="" min="1" required>
                            
                        </div>

                        <button class="btn btn-primary mt-3" type="submit">Add this Book</button>
                        </form>
                    </ul>
                    
                </div>
            </div>
            
            `;
            
            $("#displayBook").append(htmlContent)
            

        }

    }



    



    var booksInDatabase = JSON.parse(sessionStorage.getItem('books'));
    

    if (booksInDatabase){
        

        for (var i=0; i < booksInDatabase.length ; i++){
            console.log(booksInDatabase[i]);
            let isbn = booksInDatabase[i].ISBN_13
            let price = booksInDatabase[i].Price
            let quantity = booksInDatabase[i].Quantity_in_stock

            $.ajax({
                url: bookUrl + isbn,
                dataType: "json",
                success: function(response) {
                  
                  
                  if (response.totalItems === 0) {
                    alert("No book found")
                  }
                  else {
                       
                    var bookInformation = `
            
                    <div class="card mb-2">
                        <div class="card-header">
                            ISBN: ${isbn}
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">${response.items[0].volumeInfo.title}</h5>
                            <p class="card-text">Quantity: ${quantity}</p>
                            <p class="card-text">Price: £${price}</p>
                            <form action="../php/deleteBook.php" method="post">
                                <input hidden name="isbn" value="${isbn}"></input>
                                <button class="btn btn-danger" id="${isbn}" type="submit">Remove</button>
                            </form>
                        </div>
                    </div>
                    
                    `;

                    

                    $("#listOfListings").append(bookInformation);

                    

                  }
                },
                error: function () {
                  alert("Something went wrong.. <br>"+"Try again!");
                }
            });

            
            
        }
 
    } else {
        console.log("no books")
    }

    

    var orders = JSON.parse(sessionStorage.getItem('orders'));
    var orderItems = JSON.parse(sessionStorage.getItem('order_items'));

    if (orders){
        
        for (var i = 0; i <orders.length; i++){ 

            

            

            var orderCard = `
            <div class="card mb-2 mt-2">
                <div class="card-header">
                    Order Number: ${orders[i].Order_ID}
                </div>
                <div class="card-body">
                    <h5 class="card-title">Order For ${orders[i].First_name}</h5>
                    <p class="card-text">Total Price: £${orders[i].Total_price}</p>
                    <p class="card-text">Order Status: ${orders[i].Order_status}</p>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#${orders[i].Order_ID}" ">View More</button>
                </div>
            </div>

            `

            var address2;
            if (orders[i].Address_line_2 === null){
                address2 = ""
            } else {
                address2 = orders[i].Address_line_2
            }


            var orderModal = `
            <div class="modal fade" id="${orders[i].Order_ID}" tabindex="-1" aria-labelledby="ordermodallabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addbookmodallabel">Order Details</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">

                        <div id="itemsOrderedList">
                            <h5>Items Ordered:</h5>
                        </div>
                        <h6>Total Price: ${orders[i].Total_price}</h6>

                        <br>
                        <h6>Information:</h6>
                        <p>Address: ${orders[i].Address_line_1}, ${address2} ${orders[i].Postcode}</p>
                        <p>Email: ${orders[i].Email_address} </p>

                        <form action="../php/updateStatus.php" method="post">
                            <input hidden name="orderID" value="${orders[i].Order_ID}"></input>
                            <label for="status" class="form-label">Status</label>
                            <select class="form-select w-50" id="status" name ="status" required>
                                <option value="${orders[i].Order_status}">${orders[i].Order_status}</option>
                                <option>pending</option>
                                <option>shipped</option>
                                <option>completed</option>
                            </select>
                            <div class="invalid-feedback">
                                Please select a valid option.
                            </div>
                            <button class="mt-2 btn btn-primary" type="submit"> Update Status </btn>
                        </form>

                        
                        
                        </div>
                        
                    </div>
                </div>
            </div>
            `


            $("#listOfOrders").append(orderCard);
            $('#listOfOrders').append(orderModal);


            for(var j = 0; j<orderItems.length; j++){
                if ( orders[i].Order_ID === orderItems[j].Order_ID ){
                    
                    var listOfItemsOrdered = `
                            <p> Book ISBN: ${orderItems[j].Book_ISBN}  Quantity: ${orderItems[j].Quantity_ordered} </p>
                            `

                    $("#itemsOrderedList").append(listOfItemsOrdered);


                }
            }
        }


        
    }




});