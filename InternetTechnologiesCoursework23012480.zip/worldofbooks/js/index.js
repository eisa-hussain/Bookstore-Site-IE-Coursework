$(document).ready(function(){

    
    if (sessionStorage.getItem("orders") !== null) {
        sessionStorage.removeItem("orders");
        
      }
      if (sessionStorage.getItem("order_items") !== null) {
        sessionStorage.removeItem("order_items");
        
      }


    $.ajax({
        url: "php/fetchBooksFromDatabase.php", 
        type: "GET", 
        success: function(response) {
            
            $("body").append(response);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            
            console.error("Error:", textStatus, errorThrown);
        }
    });
    
    
    
    

    var item, title, author, bookImg, bookIsbn
    
    var outputList = $("#bookSection")
    var placeHolder = '<img src = "https://via.placeholder.com/150">'
    var searchData;


    // listener for search button
    $("#searchbutton").click(function(){
        outputList.empty()
        searchData = $("#query").val();
        $("h2#titleofSearch").text("Results for "+ searchData);

        if(searchData === "" || searchData === undefined){
            alert("no input");
        }
        else{
            for (var i = 0; i < booksInDatabase.length; i++){

                let isbn = booksInDatabase[i].ISBN_13
                let price = booksInDatabase[i].Price
                let quantity = booksInDatabase[i].Quantity_in_stock
    
                $.ajax({
                    url: 'https://www.googleapis.com/books/v1/volumes?q=isbn:' + isbn,
                    dataType: "json",
                    success: function(response) {
                      
                      
                      if (response.totalItems === 0) {
                        alert("No book found")
                      }
                      else {
                        let bookName = (response.items[0].volumeInfo.title)

                        if ((bookName.toLowerCase()).includes(searchData.toLowerCase()) ){
                            displayResults(response.items[0], isbn, quantity, price);
                        }
                        
                      }
                    },
                    error: function () {
                      alert("Something went wrong.. <br>"+"Try again!");
                    }
                });
            
            } 
            $("#query").val(""); 

            setTimeout(function() {
                if ($("#bookSection").text().trim() === "") {
                  $("#bookSection").append("<p>No results</p>")
                }
              }, 3000);

        }
            
    })          
            
        
        
    


    function displayResults(result, isbn, quantity, price){

        
        
        
            

        item = result;
        
        title = item.volumeInfo.title;
        author = item.volumeInfo.authors;
        bookPrice = price;
        bookQuantity = quantity;
        bookLink = item.volumeInfo.previewLink;
        bookIsbn = isbn
        bookImg = (item.volumeInfo.imageLinks) ? item.volumeInfo.imageLinks.thumbnail : placeHolder ; 

        
        createResultCard(title,author,bookPrice,bookQuantity,bookLink,bookIsbn, bookImg);
            

        

    }


    function createResultCard(title,author,bookPrice,bookQuantity,bookLink,bookIsbn, bookImg){

        
        
       

        var card = `
        <div class="col-md-6 col-lg-4 col-xl-4">
            <div class="card text-center" style="width: 18rem;">
                <img class="card-img-top" src=${bookImg} alt="preview" />
                <div class="card-body">
                    <h5 class="card-title">${title}</h5>
                    <p class="card-text">${author}</p>
                    <h5 class="card-title">£${bookPrice}</h5>
                    
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            
                            <p class="card-text">${bookQuantity} in stock</p>
                        </li>
                        <li class="list-group-item">
                            <p class="card-text">ISBN: ${bookIsbn}</p>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <a href=${bookLink}>
                        <button type="button" class="btn btn-primary">
                            Preview
                        </button>
                    </a>
                    <button type="button" class="btn btn-primary" id="addToBasketButton" data-toggle="modal" data-target="#addToBasketModal" data-isbn="${bookIsbn}" data-price="${bookPrice}" data-title="${title}" data-quantity="${bookQuantity}" data-author="${author}">
                    Add To Basket
                    </button>

                    
                    
                </div>
            </div>
        </div>
    
    `;


    
        let bookFound = booksInDatabase.some(book => book.ISBN_13 === bookIsbn);
        if (bookFound){
            $("#bookSection").append(card);
        }
        
    }


    var booksInDatabase = JSON.parse(sessionStorage.getItem('books'));

    if (booksInDatabase){

        for (var i = 0; i < booksInDatabase.length; i++){

            let isbn = booksInDatabase[i].ISBN_13
            let price = booksInDatabase[i].Price
            let quantity = booksInDatabase[i].Quantity_in_stock

            $.ajax({
                url: 'https://www.googleapis.com/books/v1/volumes?q=isbn:' + isbn,
                dataType: "json",
                success: function(response) {
                  
                  
                  if (response.totalItems === 0) {
                    alert("No book found")
                  }
                  else {
                    displayResults(response.items[0], isbn,quantity, price);
                    //console.log(response);
                  }
                },
                error: function () {
                  alert("Something went wrong.. <br>"+"Try again!");
                }
            });
        
        } 

    } else{
        console.log("REDIRECT TO NO BOOK PAGE")
    }


    $("#bookSection").on("click", "#addToBasketButton", function() {
        const isbn = $(this).data("isbn");
        const price = $(this).data("price");
        const title = $(this).data("title");
        const quantity = $(this).data("quantity");
        const author = $(this).data("author");
    
        var enoughInStock = true;  
        let quantityInBasket = 0;      

        
        let basketItems = JSON.parse(sessionStorage.getItem("basket")) || [];

        
        const existingItemIndex = basketItems.findIndex(item => item.isbn === isbn);

        if (existingItemIndex !== -1) { 
            
            const existingBookItem = basketItems[existingItemIndex];
            
            if ((existingBookItem.quantity) === quantity){
                console.log("Not available")
                enoughInStock = false;
            } else {

            
            existingBookItem.quantity = existingBookItem.quantity ? existingBookItem.quantity + 1 : 1;
            quantityInBasket = existingBookItem.quantity;

            
            basketItems[existingItemIndex] = existingBookItem;
            }
        } else {
            
            const bookItem = {
                isbn: isbn,
                title: title,
                price: price,
                quantity: 1
            };
            quantityInBasket = 1;
            
            basketItems.push(bookItem);
        }

        
        sessionStorage.setItem("basket", JSON.stringify(basketItems));

        
        if(!enoughInStock){
            $("#addBookToBasketModalBody").html("<p>Not enough in stock</p>");
        } else{
            $("#addBookToBasketModalBody").html("<p>Successfully added to basket</p>");
            $("#addBookToBasketModalBody").append("Quantity of item in basket: "+quantityInBasket);
        }

        $("#addBookToBasketModalHeader").html(title +" by "+ author);
        $('#addBookToBasketModal').modal('show');
        
        

      });
    

      
      

      let basketItems = JSON.parse(sessionStorage.getItem("basket")) || [];

      
      const totalQuantity = basketItems.reduce((acc, item) => acc + item.quantity, 0);
    
      $("#basketButton").html("Basket (" + totalQuantity +")" )


});