$(document).ready(function(){

    
    var item, title, author, publisher, bookImg, bookIsbn
    
    var outputList = $("#bookSection")
    var bookUrl = "https://www.googleapis.com/books/v1/volumes?q="
    var placeHolder = '<img src = "https://via.placeholder.com/150">'
    var searchData;


    
    $("#searchbutton").click(function(){
        outputList.empty()
        searchData = $("#query").val();
        $("h2#titleofSearch").text("Results for "+ searchData);

        if(searchData === "" || searchData === undefined){
            alert("no input");
        }
        else{
            $.ajax({ 
                url: bookUrl + searchData +"&filter=free-ebooks",
                dataType: "json",
                success: function(response) {
                  
                  
                  if (response.totalItems === 0) {
                    
                    $("#bookSection").append($("<p />").html("No Results Found"));
                  }
                  else {
                    displayResults(response);
                  }
                },
                error: function () {
                  alert("Something went wrong.. <br>"+"Try again!");
                }
            });
            $("#query").val(""); 
        }
            
    })          
            
        
        


    function displayResults(results){

        
        for (var i = 0; i < results.items.length ; i++){
            console.log(results.items[i]);

            item = results.items[i];
            title = item.volumeInfo.title;
            author = item.volumeInfo.authors;
            publisher = item.volumeInfo.publisher;
            bookLink = item.saleInfo.buyLink;
            
            bookImg = (item.volumeInfo.imageLinks) ? item.volumeInfo.imageLinks.thumbnail : placeHolder ; 

            
            createResultCard(title,author,publisher,bookLink,bookImg);
            

        }

    }


    function createResultCard(title,author,publisher, bookLink,bookImg){

        
        
        let containerDiv = $("<div />")
            .addClass("col-md-6 col-lg-4 col-xl-4");
        
        let cardDiv = $("<div />")
            .addClass("card ")
            .attr("style","width: 18rem;");
        
        let cardImage = $("<img />")
            .addClass("card-img-top")
            .attr("src",bookImg)
            .attr("alt","preview");

        let cardBodyDiv1 = $("<div />")
            .addClass("card-body");
        
        let cardTitle = $("<h5 />")
            .addClass("card-title")
            .html(title);
            

        let cardAuthor = $("<p />")
            .addClass("card-text")
            .html(author);
        
        let stockList = $("<ul />")
            .addClass("list-group list-group-flush");

        let stockItem = $("<li />")
            .addClass("list-group-item")
            .html("Available Now");

        let cardBodyDiv2 = $("<div />")
            .addClass("card-body");
        
            
        let ahrefToBook = $("<a />")
            .attr("href",bookLink);

        let viewButton = $("<button />")
            .addClass("btn btn-primary")
            .attr("type", "button")
            .html("Read Now");

        

        

        stockList.append(stockItem);
        cardBodyDiv1.append(cardTitle);
        cardBodyDiv1.append(cardAuthor);
        cardBodyDiv1.append(stockList);
        ahrefToBook.append(viewButton);
        cardBodyDiv2.append(ahrefToBook);
        
        
        cardBodyDiv1.append(cardBodyDiv2);
        
        cardDiv.append(cardImage);
        cardDiv.append(cardBodyDiv1);

        containerDiv.append(cardDiv);
        
        $("#bookSection").append(containerDiv);

    }


    let basketItems = JSON.parse(sessionStorage.getItem("basket")) || [];

    
    const totalQuantity = basketItems.reduce((acc, item) => acc + item.quantity, 0);
  
    $("#basketButton").html("Basket (" + totalQuantity +")" )

});