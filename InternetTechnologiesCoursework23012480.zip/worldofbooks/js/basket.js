$(document).ready(function(){



    let basketItems = JSON.parse(sessionStorage.getItem("basket")) || [];

    console.log(basketItems)
      
      const totalQuantity = basketItems.reduce((acc, item) => acc + item.quantity, 0);
      const totalPrice = basketItems.reduce((acc, item) => acc + (item.quantity * item.price), 0);
    
      $("#basketButton").html("Basket (" + totalQuantity +")" );


    $("#basketSize").html(totalQuantity);
    $("#totalPrice").append("<strong>£"+ totalPrice.toFixed(2) +"</strong>")

    

    for (var i =0; i<basketItems.length ; i++){
        
        let totalPriceOfItem = (basketItems[i].price * basketItems[i].quantity).toFixed(2);
        var basketItemHTML = `
            <li class="list-group-item d-flex justify-content-between lh-sm">
                
                <div>
                   <h6 class="my-0">${basketItems[i].quantity}x ${basketItems[i].title}</h6>
                    <small class="text-muted">£${totalPriceOfItem}</small>
                </div>
                
                
                <button class="btn btn-danger removeItemFromBasket" data-isbn="${basketItems[i].isbn}" id="removeItemFromBasket">x</button>
            </li>
            
        `

        $("#listOfItems").append(basketItemHTML);
    };



    $(".removeItemFromBasket").click(function(){
        let isbn = $(this).data("isbn");
        

        basketItems = basketItems.map(item => {
            if (item.isbn === isbn) {
              return item.quantity > 1 ? { ...item, quantity: item.quantity - 1 } : null;
            } else {
              return item;  
            }
          });
        
          
          basketItems = basketItems.filter(item => item !== null);
        
          
          sessionStorage.setItem("basket", JSON.stringify(basketItems));

          window.location.reload();

    });



    $("#submitDetailsForm").submit(function(event) {
        event.preventDefault();
        
        const firstname = $("#firstName").val();
        const lastname = $("#lastName").val();
        const email = $("#email").val();
        const address1 = $("#address").val();
        const address2 = $("#address2").val();
        const country = $("#country").val();
        const postcode = $("#postcode").val();
        const cardname = $("#cc-name").val();
        const cardnumber = $("#cc-number").val();
        const cardexpiration = $("#cc-expiration").val();
        const cardcvv = $("#cc-cvv").val();
        const orderstatus = "pending";

        $.ajax({
            url: "../php/postOrder.php", 
            type: "POST", 
            data: {
              firstname: firstname,
              lastname: lastname,
              totalprice: totalPrice.toFixed(2),
              email: email,
              address1: address1,
              address2: address2,
              country: country,
              postcode: postcode,
              cardname: cardname,
              cardnumber: cardnumber,
              cardexpiration: cardexpiration,
              cardcvv: cardcvv,
              basketData: JSON.stringify(basketItems),
              orderstatus: orderstatus


            },
            success: function(response) {
              
              console.log("success");
              console.log("response")
            },
            error: function(jqXHR, textStatus, errorThrown) {
              
              console.error("AJAX Error:", textStatus, errorThrown);
            }
          });



      });

});