<?php

$isbn = $_POST['isbn'];
$price = $_POST['price'];
$quantity = $_POST['quantity'];


$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = '';
$DATABASE_NAME = 'worldofbooks';


try{
    $conn = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
    if ( mysqli_connect_errno() ) {

        exit('Failed to connect to MySQL: ' . mysqli_connect_error());
    }


    $sql = "INSERT INTO books (ISBN_13, Quantity_in_stock, Price) VALUES ('$isbn', '$quantity', '$price')";


    if ($conn->query($sql) === TRUE) {
        
        echo "<script>alert('Success');</script>";
    } else {
        echo "<script>alert('Not successful: Duplicate entry');</script>";
    }

} catch (mysqli_sql_exception $e) {

    echo "<script>alert('Not successful: This book already exists in the Database.');</script>";
}

echo "<script>setTimeout(function() { window.location.href = 'adminPage.php'; }, 1000);</script>";

exit();
?>