<?php

session_start();

if (!isset($_SESSION['loggedin'])) {
	header('Location: ../index.html');
	exit;
}
?>

<!doctype html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>World Of Books</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
      <link rel="stylesheet" type="text/css" href="../css/style.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
   </head>
   
   
   
   
   <body>
      
   <?php include 'fetchBooksFromDatabase.php';
   include 'fetchOrderItemsFromDatabase.php'; 
   include 'fetchOrdersFromDatabase.php';?> 
   

    <nav class="navbar navbar-expand-lg bg-body-tertiary bg-dark" data-bs-theme="dark">
         <div class="container-fluid">
            <a class="navbar-brand" href="">World Of Books Admin</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarScroll">
               <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
               <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="logout.php">Log Out</a>
               </li>
               
            </div>
         </div>
      </nav>



     
      <div class="container">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
         <li class="nav-item" role="presentation">
           <button class="nav-link active" id="orders-tab" data-bs-toggle="tab" data-bs-target="#orders" type="button" role="tab" aria-controls="orders" aria-selected="true">Orders</button>
         </li>
         <li class="nav-item" role="presentation">
           <button class="nav-link" id="listings-tab" data-bs-toggle="tab" data-bs-target="#listings" type="button" role="tab" aria-controls="listings" aria-selected="false">Listings</button>
         </li>
         <li class="nav-item" role="presentation">
           <button class="nav-link" id="accounts-tab" data-bs-toggle="tab" data-bs-target="#accounts" type="button" role="tab" aria-controls="accounts" aria-selected="false">Accounts</button>
         </li>
       </ul>
       <div class="tab-content" id="myTabContent">
         <div class="tab-pane fade show active" id="orders" role="tabpanel" aria-labelledby="orders-tab">


         <div id="listOfOrders">

            

            </div>



         </div>
         <div class="tab-pane fade" id="listings" role="tabpanel" aria-labelledby="listings-tab">
        
                    <!-- Button trigger modal -->
            <button type="button" class="btn btn-primary mt-2 mb-2" data-bs-toggle="modal" data-bs-target="#addbookmodal">
            Create A Listing...
            </button>

            <!-- Modal -->
            <div class="modal fade" id="addbookmodal" tabindex="-1" aria-labelledby="addbookmodallabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addbookmodallabel">Create Listing</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="AddBookModalBody">
                    <form>
                        
                        <label for="enterISBN" class="col-form-label ">Enter ISBN 13:</label>
                        <input id="enterISBN" type="text" class="form-control w-50 " placeholder="Enter ISBN">
                        <button type="button" id="findBookToAdd" class="btn btn-primary mt-2 mb-2">Search</button>
                        <div id ="displayBook">

                        </div>
                        
                    </form>
                </div>
                <div class="modal-footer"> 
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    
                </div>
                </div>
            </div>
            </div>

                <div id="listOfListings">

                    
                
                </div>

         </div>
         <div class="tab-pane fade" id="accounts" role="tabpanel" aria-labelledby="accounts-tab">...</div>
       </div>

      </div>



      
      
      
      
      
      <footer class="bg-dark py-5 mt-2 ">
         <div class="container text-light text-center">
            
            <small class="text-white-50">World of Books 2024</small>
            <br>
            
         </div> 
      </footer>




      
      <script src="../js/adminPage.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
   
   
    </body>
</html>