In order to run the web application, import the database (worldofbooks.sql) into phpmyadmin. Then, ensure the worldofbooks folder is located within the htdocs folder within the folder of the xampp installation (/examplepath/xampp/htdocs). 
The admin login is: 
	username: admin	
	password: test

